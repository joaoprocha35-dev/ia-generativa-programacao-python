import calculos

print("Opções disponíveis:")
print("1 - Calcular a soma entre dois números")
print("2 - Calcular a subtração entre dois números")
print("3 - Calcular a divisão entre dois números")
print("4 - Calcular a multiplicação entre dois números")

response = int(input("Digite a opção desejada: "))

if (response == 1):
    value1 = float(input("Digite o valor do primeiro número: "))
    value2 = float(input("Digite o valor do segundo número: "))
    
    result = calculos.sum(value1, value2)
    print(f"O resultado da operação é: {result}")

elif (response == 2):
    value1 = float(input("Digite o valor do primeiro número: "))
    value2 = float(input("Digite o valor do segundo número: "))

    result = calculos.subtraction(value1, value2)
    print(f"O resultado da operação é: {result}")
    
elif (response == 3):
    value1 = float(input("Digite o valor do primeiro número: "))
    value2 = float(input("Digite o valor do segundo número: "))

    result = calculos.multiplication(value1, value2)
    print(f"O resultado da operação é: {result}")

elif (response == 4):
    value1 = float(input("Digite o valor do primeiro número: "))
    value2 = float(input("Digite o valor do segundo número: "))

    result = calculos.division(value1, value2)
    print(f"O resultado da operação é: {result}")

else:
    print("Operação inválida!")