# Função que calcula a soma
def sum (value1, value2):
    result = value1 + value2
    return result

# Função que calcula a subtração
def subtraction (value1, value2):
    result = value1 - value2
    return result

# Função que calcula a multiplicação
def multiplication (value1, value2):
    result = value1 * value2
    return result

# Função que calcula a divisão
def division (value1, value2):
    result = value1 / value2
    return result
