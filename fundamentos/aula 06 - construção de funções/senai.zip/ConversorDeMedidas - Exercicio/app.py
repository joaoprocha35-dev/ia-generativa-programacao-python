import util

print("Opções disponíveis:")
print("1 - Celsius para Fahrenheit")
print("2 - Fahrenheit para Celsius")

response = int(input("Digite a opção desejada: "))

if (response == 1):
    value = float(input("Digite a temperatura: "))
    result = util.CelsiusToFahrenheit(value)

    print(f"O resultado da conversão é: {result}")

elif (response == 2):
    value = float(input("Digite a temperatura: "))
    result = util.FahrenteitToCelsius(value)

    print(f"O resultado da conversão é: {result}")

else:
    print("Opção Inválida!")