# Celsius para Fahrenheit
def CelsiusToFahrenheit (value):
    result = (value * 1.8) + 32
    return result

def FahrenteitToCelsius (value):
    result = (value - 32) / 1.8
    return result